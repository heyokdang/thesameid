Migration from v4 to v5
=======================

This document is intended to guide users through the process of migration from old version v4 to v5.

What's new in v5?
----------------------------------------

1. You can check the list of new features in CHANGELOG.md
2. Minimum supported version of PHP is **5.3** because of namespaces
3. Project has external depencies and can be installed only through composer
